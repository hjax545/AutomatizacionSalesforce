import { test, expect, Page, Locator } from '@playwright/test';
import * as XLSX from 'xlsx';
import * as path from 'path';


//  BLOQUE SUPERIOR: CONFIGURACIÓN, LECTURA DE EXCEL Y FUNCIONES AUXILIARES

interface LeadData {
  'Unidad de negocio': string;      // PickList
  'Tipo de persona': string;        // PickList
  'Segmento': string;               // PickList
  'Nombre': string;                 // Texto
  'Apellido': string;               // Texto
  'Tipo de identificación': string; // PickList
  'Número de Identificación': string; // Texto
  'Correo electrónico': string;     // Texto / Email
  'Telefono Fijo': string;          // Texto / Teléfono
  'Teléfono móvil': string;         // Texto / Teléfono
  'Departamento': string;           // PickList
  'Ciudad': string;                 // PickList
  'País': string;                   // PickList
}

// Función para cargar los datos del Excel
function obtenerDatosExcel(rutaArchivo: string): LeadData[] {
  const workbook = XLSX.readFile(rutaArchivo);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json<LeadData>(sheet);
}


// Función auxiliar para manipular desplegables (PickLists) de Salesforce Lightning
async function seleccionarPickList(container: Locator, page: Page, nombreCampo: string, valor: string) {
  if (!valor) return;

  // 1. Buscamos el elemento por su etiqueta visible (Label)
  const campo = container.getByLabel(nombreCampo).first();

  // 2. Verificamos si es un selector <select> nativo de HTML
  const esSelectNativo = await campo.evaluate((el) => el.tagName === 'SELECT').catch(() => false);

  if (esSelectNativo) {
    // Si es un <select> nativo, usamos .selectOption() en lugar de .click()
    await campo.selectOption({ label: valor.trim() });
    console.log(`  ✓ Seleccionado (Nativo): "${valor}" en ${nombreCampo}`);
  } else {
    // Si es un combobox custom de Salesforce Lightning:
    await campo.click();
    
    const opcionCustom = page.locator(
      `lightning-base-combobox-item:has-text("${valor}"), [role="option"]:has-text("${valor}")`
    ).first();

    await opcionCustom.waitFor({ state: 'visible', timeout: 5000 });
    await opcionCustom.click();
    console.log(`  ✓ Seleccionado (Custom): "${valor}" en ${nombreCampo}`);
  }
}

// Variables de credenciales y URL
const URL_SALESFORCE = 'https://rentingcolombia--preprodfe.sandbox.lightning.force.com/';
const USERNAME = 'hrobledo@rentingcolombia.com.preprodfe'; 
const PASSWORD = 'transformise1';



// BLOQUE DE EJECUCIÓN DEL TEST


test('Procesar Leads de Excel en Salesforce (2 Pantallas)', async ({ page }) => {
  test.setTimeout(300000); // Timeout extendido (5 minutos)

  // Cargar el archivo Excel desde la raíz del proyecto
  const rutaExcel = path.join(__dirname, '../datos_leads.xlsx');
  const listaLeads = obtenerDatosExcel(rutaExcel);
  console.log(`Leads encontrados en el Excel: ${listaLeads.length}`);


  // INICIALIZACIÓN: LOGIN Y NAVEGACIÓN A LEADS

  await page.goto(URL_SALESFORCE);
  await page.locator('#username').fill(USERNAME);
  await page.locator('#password').fill(PASSWORD);
  await page.locator('#Login').click();
  await page.waitForURL(/.*lightning.force.com.*/, { timeout: 120000 });

  // Navegar a la sección de Leads usando el App Launcher

  const appLauncher = page.locator('.slds-icon-waffle');
  await appLauncher.waitFor({ state: 'visible' });
  await appLauncher.click();

  const searchAppInput = page.getByPlaceholder(/Buscar aplicaciones|Search apps/i);
  await searchAppInput.fill('Leads');

  const leadOption = page.locator('one-app-launcher-menu-item').filter({ hasText: /Leads|Candidatos/i }).first();
  await leadOption.click();


  // 1. Espera a que la URL contenga "/Lead/"
  await page.waitForURL(/.*\/Lead\/.*/i, { timeout: 15000 });
  
  // 2. Espera a que la red y el DOM se estabilicen
  await page.waitForLoadState('networkidle').catch(() => {});
  
  // 3. Pausa de seguridad de 2 segundos para dar tiempo a que renderice la tabla y botones
  await page.waitForTimeout(2000);



  //  BUCLE DE INTERACCIONES (SE REPITE POR CADA REGISTRO DEL EXCEL)
  
  for (const [index, lead] of listaLeads.entries()) {
    console.log(`Procesando Lead ${index + 1} de ${listaLeads.length}: ${lead.Nombre} ${lead.Apellido}`);

    // A. Clic en botón "Nuevo"
    const btnNuevo = page.getByRole('button', { name: /Nuevo|New/i }).first();
    await btnNuevo.click();


    // B. INTERACCIÓN EN PANTALLA 1 (PRIMEROS 3 PICKLISTS)

    const modalPaso1 = page.locator('.actionBody, .modal-container').first();
    await modalPaso1.waitFor({ state: 'visible' });

    // 1. Unidad de negocio
    await seleccionarPickList(modalPaso1, page, 'Unidad de negocio', lead['Unidad de negocio']);

    // 2. Tipo de persona
    await seleccionarPickList(modalPaso1, page, 'Tipo de persona', lead['Tipo de persona']);

    // 3. Segmento
    await seleccionarPickList(modalPaso1, page, 'Segmento', lead['Segmento']);

    // Clic en "Siguiente" para avanzar de pantalla
    const btnSiguiente = modalPaso1.getByRole('button', { name: /Siguiente|Next/i });
    await btnSiguiente.click();
    await page.waitForTimeout(1500);

    // C. INTERACCIÓN EN PANTALLA 2 (FORMULARIO GENERAL COMPLETO)

    const modalPaso2 = page.locator('.actionBody, .modal-container').first();
    await modalPaso2.waitFor({ state: 'visible' });

    // --- PickLists de Pantalla 2 ---
    // 4. Tipo de identificación
    await seleccionarPickList(modalPaso2, page, 'Tipo de identificación', lead['Tipo de identificación']);

    // 5. Departamento
    await seleccionarPickList(modalPaso2, page, 'Departamento', lead['Departamento']);

    // 6. Ciudad
    await seleccionarPickList(modalPaso2, page, 'Ciudad', lead['Ciudad']);

    // 7. País
    await seleccionarPickList(modalPaso2, page, 'País', lead['País']);


    // --- Campos de Texto e Identificación de Pantalla 2 ---
    // 8. Nombre (Usa atributo name="NombrePN" o etiqueta visible)
    if (lead.Nombre) {
      await modalPaso2.locator('input[name="NombrePN"]')
          .or(modalPaso2.getByLabel(/Nombre|First Name/i))
          .fill(lead.Nombre);
    }

    // 9. Apellidos
    if (lead.Apellido) {
      await modalPaso2.getByLabel(/Apellidos|Last Name/i).fill(lead.Apellido);
    }

    // 10. Número de Identificación Número de Identificación
    if (lead['Número de Identificación']) {
      await modalPaso2.getByLabel('Número de Identificación')
          .or(modalPaso2.locator('input[name*="Numero_de_Identificacion"]'))
          .fill(String(lead['Número de Identificación']));
    }

    // 11. Correo electrónico
    if (lead['Correo electrónico']) {
      await modalPaso2.getByLabel(/Correo electrónico|Email/i).fill(lead['Correo electrónico']);
    }

    // 12. Teléfono Fijo
    if (lead['Telefono Fijo']) {
      await modalPaso2.getByLabel(/Telefono Fijo|Teléfono/i).first().fill(String(lead['Telefono Fijo']));
    }

    // 13. Teléfono móvil
    if (lead['Teléfono móvil']) {
      await modalPaso2.getByLabel(/Teléfono móvil|Móvil|Mobile/i).fill(String(lead['Teléfono móvil']));
    }


    // D. GUARDAR Y FINALIZAR EL REGISTRO ACTUAL}

    const btnGuardar = modalPaso2.getByRole('button', { name: /Siguiente|Next|Guardar|Save/i, exact: true });
    await btnGuardar.click();

    // Esperar a que el modal se cierre antes de procesar el siguiente Lead
    await modalPaso2.waitFor({ state: 'detached', timeout: 120000 }).catch(() => {});
    await page.waitForTimeout(2000);
  }

  // Pausa opcional al finalizar para revisar en pantalla
  await page.pause();
});