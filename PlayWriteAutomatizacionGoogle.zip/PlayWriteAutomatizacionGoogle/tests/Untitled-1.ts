
  import { test, expect, Page, Locator } from '@playwright/test';
import * as XLSX from 'xlsx';
import * as path from 'path';

// ---------------------------------------------------------------------------
// 1. ESTRUCTURA DE LOS DATOS DEL EXCEL
// ---------------------------------------------------------------------------
interface LeadData {
  'Unidad de negocio': string;      // PickList
  'Tipo de persona': string;        // PickList
  'Segmento': string;               // PickList
  'Nombre': string;                 // Texto
  'Apellido': string;               // Texto
  'Tipo de identificación': string; // PickList
  'Número de Identificación': string; // Texto
  'Correo electrónico': string;     // Texto / Email
  'Telefono Fijo': string;          // Texto / Teléfono
  'Teléfono móvil': string;         // Texto / Teléfono
  'Departamento': string;           // PickList
  'Ciudad': string;                 // PickList
  'País': string;                   // PickList
}

function obtenerDatosExcel(rutaArchivo: string): LeadData[] {
  const workbook = XLSX.readFile(rutaArchivo);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json<LeadData>(sheet);
}

// ---------------------------------------------------------------------------
// 2. FUNCIÓN AUXILIAR REUTILIZABLE PARA PICKLISTS DE SALESFORCE
// ---------------------------------------------------------------------------
async function seleccionarPickList(container: Locator, page: Page, nombreCampo: string, valor: string) {
  if (!valor) return; // Si el Excel tiene la celda vacía, no hace nada

  // Abre el desplegable buscando por el nombre del campo/etiqueta
  const combo = container.getByRole('combobox', { name: new RegExp(nombreCampo, 'i') })
      .or(container.locator(`button[aria-label*="${nombreCampo}"]`))
      .or(container.locator(`input[aria-label*="${nombreCampo}"]`));
  
  await combo.click();

  // Selecciona la opción deseada dentro del menú desplegado
  const opcion = page.getByRole('option', { name: valor, exact: true })
      .or(page.locator(`lightning-base-combobox-item:has-text("${valor}")`));
  
  await opcion.click();
}

// ---------------------------------------------------------------------------
// 3. PRUEBA PRINCIPAL
// ---------------------------------------------------------------------------
const URL_SALESFORCE = 'https://rentingcolombia--preprodfe.sandbox.lightning.force.com/';
const USERNAME = 'hrobledo@rentingcolombia.com.preprodfe'; 
const PASSWORD = 'transformise1';

test('Crear Leads masivos en Salesforce desde Excel', async ({ page }) => {
  test.setTimeout(240000); // 4 minutos de margen

  const rutaExcel = path.join(__dirname, '../datos_leads.xlsx');
  const listaLeads = obtenerDatosExcel(rutaExcel);

  // --- LOGIN ---
  await page.goto(URL_SALESFORCE);
  await page.locator('#username').fill(USERNAME);
  await page.locator('#password').fill(PASSWORD);
  await page.locator('#Login').click();
  await page.waitForURL(/.*lightning.force.com.*/, { timeout: 30000 });

  // --- NAVEGAR A LEADS ---
  const appLauncher = page.locator('.slds-icon-waffle');
  await appLauncher.waitFor({ state: 'visible' });
  await appLauncher.click();

  const searchAppInput = page.getByPlaceholder(/Buscar aplicaciones|Search apps/i);
  await searchAppInput.fill('Leads');

  const leadOption = page.locator('one-app-launcher-menu-item').filter({ hasText: /Leads|Candidatos/i }).first();
  await leadOption.click();

  // --- ITERACIÓN POR CADA FILA DEL EXCEL ---
  for (const [index, lead] of listaLeads.entries()) {
    console.log(`Procesando fila ${index + 1}: ${lead.Nombre} ${lead.Apellido}`);

    // Clic en botón "Nuevo"
    const btnNuevo = page.getByRole('button', { name: /Nuevo|New/i }).first();
    await btnNuevo.click();

    // Referencia al contenedor modal emergente
    const modal = page.locator('.actionBody, .modal-container, div[role="dialog"]');
    await modal.waitFor({ state: 'visible' });

    // =======================================================================
    // 📍 DÓNDE DEFINIR CADA LOCALIZADOR
    // =======================================================================

    // --- CAMPOS PICKLIST (Desplegables) ---
    // 1. Unidad de negocio
    await seleccionarPickList(modal, page, 'Unidad de negocio', lead['Unidad de negocio']);

    // 2. Tipo de persona
    await seleccionarPickList(modal, page, 'Tipo de persona', lead['Tipo de persona']);

    // 3. Segmento
    await seleccionarPickList(modal, page, 'Segmento', lead['Segmento']);

    // 4. Tipo de identificación
    await seleccionarPickList(modal, page, 'Tipo de identificación', lead['Tipo de identificación']);

    // 5. Departamento
    await seleccionarPickList(modal, page, 'Departamento', lead['Departamento']);

    // 6. Ciudad
    await seleccionarPickList(modal, page, 'Ciudad', lead['Ciudad']);

    // 7. País
    await seleccionarPickList(modal, page, 'País', lead['País']);


    // --- CAMPOS DE TEXTO E INSUMO DIRECTO ---
    
    // 8. Nombre
    // 📍 LOCALIZADOR: Si en Salesforce dice "Primer nombre" o "First Name", ajusta el texto en getByLabel
    if (lead.Nombre) {
      await modal.getByLabel('Nombre', { exact: false }).or(modal.getByPlaceholder(/Nombre|First Name/i)).fill(lead.Nombre);
    }

    // 9. Apellido (Campo obligatorio normalmente)
    // 📍 LOCALIZADOR: Salesforce suele llamarlo "* Apellidos" o "Apellidos"
    if (lead.Apellido) {
      await modal.getByLabel(/Apellidos|Last Name/i).fill(lead.Apellido);
    }

    // 10. Número de Identificación
    // 📍 LOCALIZADOR: Cambia 'Número de Identificación' por el nombre exacto de la etiqueta del formulario
    if (lead['Número de Identificación']) {
      await modal.getByLabel(/Número de Identificación|Identificación/i).fill(String(lead['Número de Identificación']));
    }

    // 11. Correo electrónico
    // 📍 LOCALIZADOR: Revisa si la etiqueta en la pantalla es "Correo electrónico" o "Email"
    if (lead['Correo electrónico']) {
      await modal.getByLabel(/Correo electrónico|Email/i).fill(lead['Correo electrónico']);
    }

    // 12. Teléfono Fijo
    // 📍 LOCALIZADOR: Revisa la etiqueta exacta en el formulario (ej. "Teléfono fijo" o "Teléfono")
    if (lead['Telefono Fijo']) {
      await modal.getByLabel(/Telefono Fijo|Teléfono/i).first().fill(String(lead['Telefono Fijo']));
    }

    // 13. Teléfono móvil
    // 📍 LOCALIZADOR: Revisa si la etiqueta es "Teléfono móvil" o "Móvil" / "Cell Phone"
    if (lead['Teléfono móvil']) {
      await modal.getByLabel(/Teléfono móvil|Móvil|Mobile/i).fill(String(lead['Teléfono móvil']));
    }

    // =======================================================================
    // GUARDAR EL REGISTRO
    // =======================================================================
    const btnGuardar = modal.getByRole('button', { name: /Guardar|Save/i, exact: true });
    await btnGuardar.click();

    // Esperar a que el modal se cierre antes de pasar a la siguiente iteración
    await modal.waitFor({ state: 'detached', timeout: 15000 }).catch(() => {});
    await page.waitForTimeout(2000);
  }

  await page.pause();
});