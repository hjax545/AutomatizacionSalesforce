import { test, expect } from '@playwright/test';

test('Buscar en DuckDuckGo "La llamada del dios de la forja ornn"', async ({ page }) => {
  const searchText = 'La llamada del dios de la forja ornn';

  // 1. Ir a DuckDuckGo
  await page.goto('https://duckduckgo.com/');

  // 2. Aceptar cookies en caso de que aparezca el botón
  const acceptCookiesButton = page.getByRole('button', { name: /Aceptar todo|Accept all|Aceptar/i });
  if (await acceptCookiesButton.isVisible().catch(() => false)) {
    await acceptCookiesButton.click();
  }

  // 3. Localizar el buscador
  const searchInput = page.locator('textarea[name="q"], input[name="q"]').first();
  await expect(searchInput).toBeVisible();

  // 4. Escribir simulando ritmo humano (100ms por tecla) para evitar el CAPTCHA
  await searchInput.pressSequentially(searchText, { delay: 100 });
  await searchInput.press('Enter');

  // 5. Validar que la sección de resultados sea visible
  const searchResults = page.locator('#search');
  await page.waitForTimeout(25000);

  /*

  Pausa la prueba y mantiene el navegador abierto
  await page.pause();

  Mantiene la ventana abierta por 15,000 milisegundos (15 segundos)
  await page.waitForTimeout(15000);

  Mantiene la página abierta indefinidamente hasta que cierres la terminal con Ctrl + C
  await new Promise(() => {});
  */

});