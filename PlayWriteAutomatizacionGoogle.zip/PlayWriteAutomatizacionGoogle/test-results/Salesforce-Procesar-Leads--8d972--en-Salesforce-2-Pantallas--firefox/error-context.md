# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Salesforce.spec.ts >> Procesar Leads de Excel en Salesforce (2 Pantallas)
- Location: tests\Salesforce.spec.ts:70:5

# Error details

```
Error: locator.click: Target page, context or browser has been closed
Call log:
  - waiting for locator('.actionBody, .modal-container').first().getByRole('button', { name: /Guardar|Save/i })

```

```
Error: browserContext.close: Target page, context or browser has been closed
```